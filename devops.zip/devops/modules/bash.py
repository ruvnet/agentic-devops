import click
from .utils import run_aider_command

def create_bash_script():
    click.echo("\n🚀 Creating Bash Script...")
    instructions = click.prompt("Provide Bash script creation instructions", default="Create a basic deployment script.")
    guidance = click.prompt("Provide any initial optional guidance for the AI (press Enter to skip)", default="", show_default=False)
    if guidance:
        instructions = f"{guidance}. {instructions}"
    script_path = "./script.sh"
    run_aider_command(instructions, [script_path])
    click.echo("✅ Bash Script created successfully.")
    from ..coder import coder_menu
    coder_menu()
