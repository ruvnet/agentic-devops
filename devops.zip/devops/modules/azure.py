import click
from .utils import run_aider_command

def create_azure_config():
    click.echo("\n🌐 Creating Azure Configuration...")
    instructions = click.prompt("Provide Azure configuration instructions", default="Create an Azure Resource Manager template.")
    guidance = click.prompt("Provide any initial optional guidance for the AI (press Enter to skip)", default="", show_default=False)
    if guidance:
        instructions = f"{guidance}. {instructions}"
    config_path = "./azure-config.json"
    run_aider_command(instructions, [config_path])
    click.echo("✅ Azure Configuration created successfully.")
    azure_menu()

def azure_menu():
    click.echo("\n🌐 Azure Configuration")
    click.echo("1. Create ARM Template")
    click.echo("2. Create Azure CLI Script")
    click.echo("3. Create Azure Policy")
    click.echo("4. Back to Main Menu")

    choice = click.prompt("Enter your choice", type=int)

    if choice == 1:
        create_azure_config()
    elif choice == 2:
        click.echo("\n🚀 Creating Azure CLI Script...")
        create_bash_script()  # You can adjust this to a more specific function if needed
    elif choice == 3:
        click.echo("\n🚀 Creating Azure Policy...")
        create_azure_config()  # You can adjust this to a more specific function if needed
    elif choice == 4:
        from ..coder import coder_menu
        coder_menu()
    else:
        click.echo("\n❌ Invalid choice. Please try again.")
        azure_menu()
