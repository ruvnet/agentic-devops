import click
from .utils import run_aider_command

def create_gcp_config():
    click.echo("\n🌐 Creating GCP Configuration...")
    instructions = click.prompt("Provide GCP configuration instructions", default="Create a Google Cloud Deployment Manager template.")
    guidance = click.prompt("Provide any initial optional guidance for the AI (press Enter to skip)", default="", show_default=False)
    if guidance:
        instructions = f"{guidance}. {instructions}"
    config_path = "./gcp-config.yaml"
    run_aider_command(instructions, [config_path])
    click.echo("✅ GCP Configuration created successfully.")
    gcp_menu()

def gcp_menu():
    click.echo("\n🌐 GCP Configuration")
    click.echo("1. Create Deployment Manager Template")
    click.echo("2. Create GCP CLI Script")
    click.echo("3. Create GCP IAM Policy")
    click.echo("4. Back to Main Menu")

    choice = click.prompt("Enter your choice", type=int)

    if choice == 1:
        create_gcp_config()
    elif choice == 2:
        click.echo("\n🚀 Creating GCP CLI Script...")
        create_bash_script()  # You can adjust this to a more specific function if needed
    elif choice == 3:
        click.echo("\n🚀 Creating GCP IAM Policy...")
        create_gcp_config()  # You can adjust this to a more specific function if needed
    elif choice == 4:
        from ..coder import coder_menu
        coder_menu()
    else:
        click.echo("\n❌ Invalid choice. Please try again.")
        gcp_menu()
