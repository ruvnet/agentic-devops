import click
from .utils import run_aider_command

def create_aws_config():
    click.echo("\n🌐 Creating AWS Configuration...")
    instructions = click.prompt("Provide AWS configuration instructions", default="Create a CloudFormation template.")
    guidance = click.prompt("Provide any initial optional guidance for the AI (press Enter to skip)", default="", show_default=False)
    if guidance:
        instructions = f"{guidance}. {instructions}"
    config_path = "./aws-config.yml"
    run_aider_command(instructions, [config_path])
    click.echo("✅ AWS Configuration created successfully.")
    aws_menu()

def aws_menu():
    click.echo("\n🌐 AWS Configuration")
    click.echo("1. Create CloudFormation Template")
    click.echo("2. Create AWS CLI Script")
    click.echo("3. Create IAM Policy")
    click.echo("4. Back to Main Menu")

    choice = click.prompt("Enter your choice", type=int)

    if choice == 1:
        create_aws_config()
    elif choice == 2:
        click.echo("\n🚀 Creating AWS CLI Script...")
        create_bash_script()  # You can adjust this to a more specific function if needed
    elif choice == 3:
        click.echo("\n🚀 Creating IAM Policy...")
        create_aws_config()  # You can adjust this to a more specific function if needed
    elif choice == 4:
        from ..coder import coder_menu
        coder_menu()
    else:
        click.echo("\n❌ Invalid choice. Please try again.")
        aws_menu()
